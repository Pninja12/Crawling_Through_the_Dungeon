﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Dungeon_Crawler
{
    class Program
    {
        static void Main(string[] args)
        {
            Controller controller = new Controller();
            controller.Game();
        }
    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dungeon_Crawler
{
    public abstract class PotionsLevel : Item
    {
        public int Level;
        


    }
}